import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Home from "./pages/Home";
import Drawer from "./pages/Drawer";

export default function App() {
  return <Drawer />;
}
