import React from "react";
import TesteDrawer from "../components/TesteDrawer";

export default function Home() {
  return <TesteDrawer />;
}
